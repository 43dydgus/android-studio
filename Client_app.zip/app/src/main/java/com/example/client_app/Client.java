package com.example.client_app;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

// ApiClient 클래스
class ApiClient2 {
    // API 서버의 기본 URL을 정의합니다.
    //private static final String BASE_URL2 = ""; //주소값

    // Retrofit 객체를 생성합니다.
    private static Retrofit retrofit2;

    // Retrofit 객체를 반환하는 메소드입니다.
    public static Retrofit getApiClient2(String str) {
        // Retrofit 객체가 null인 경우, Retrofit 객체를 생성합니다.
        if (retrofit2 == null) {
            retrofit2 = new Retrofit.Builder()
                    .baseUrl(str)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        // Retrofit 객체를 반환합니다.
        return retrofit2;
    }
}


public class Client {
    String str;

    public void setStr(String str) {
        this.str = str;
    }

    // 데이터를 서버로 전송하는 메소드입니다.
    public void getdatas(String startings, Callback<MyResponseIncheon> callback) {
        // Retrofit 객체를 사용하여 서버와 통신할 수 있는 인터페이스를 생성합니다.
        // getdatas apiInterface = ApiClient2.getApiClient2(this.add).create(getdatas.class);
        IgetIncheondatas apiInterface = ApiClient2.getApiClient2(str).create(IgetIncheondatas.class);
        // 로그인 API를 호출합니다.
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);//아이디

        Call<MyResponseIncheon> call = apiInterface.getdatas(jsonObject);
        call.enqueue(callback);
    }//Client

    public void getAnyang(String startings, Callback<ResponseAnyang> callback) {
        IgetAnyangdatas apiInterface = ApiClient2.getApiClient2(str).create(IgetAnyangdatas.class);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);//아이디

        Call<ResponseAnyang> call = apiInterface.getAnyang(jsonObject);
        call.enqueue(callback);
    }

    public void getSiheung(String startings, Callback<MyResponseSiheung> callback) {
        IgetSiheungdatas apiInterface = ApiClient2.getApiClient2(str).create(IgetSiheungdatas.class);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);
        Call<MyResponseSiheung> call = apiInterface.getdatas(jsonObject);
        call.enqueue(callback);
    }

    public void getMokdong(String startings, Callback<MyResponseMokdong> callback) {
        IgetMokdongdatas apiInterface = ApiClient2.getApiClient2(str).create(IgetMokdongdatas.class);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);
        Call<MyResponseMokdong> call = apiInterface.getdatas(jsonObject);
        call.enqueue(callback);
    }



    public void getBeomgye(String startings, Callback<MyResponseBeomgye> callback) {
        IgetBeomgyedatas apiInterface = ApiClient2.getApiClient2(str).create(IgetBeomgyedatas.class);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);
        Call<MyResponseBeomgye> call = apiInterface.getBeomgye(jsonObject);
        call.enqueue(callback);
    }

    public void getYeonsung(String startings, Callback<ResponseYeonsung> callback) {
        IgetYeonsungdatas apiInterface = ApiClient2.getApiClient2(str).create(IgetYeonsungdatas.class);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("startings", startings);
        Call<ResponseYeonsung> call = apiInterface.getdatas(jsonObject);
        call.enqueue(callback);
    }


    //인터페이스
    public interface IgetIncheondatas {//인천장거리
        @POST("test")
        @Headers("Content-Type: application/json")
        Call<MyResponseIncheon> getdatas(@Body JsonObject jsonObject);
    }//getdatas

    public interface IgetSiheungdatas {//시흥장거리
        @POST("test")
        @Headers("Content-Type: application/json")
        Call<MyResponseSiheung> getdatas(@Body JsonObject jsonObject);
    }

    public interface IgetMokdongdatas {//목동장거리
        @POST("test")
        @Headers("Content-Type: application/json")
        Call<MyResponseMokdong> getdatas(@Body JsonObject jsonObject);
    }

    public interface IgetAnyangdatas {//안양단거리
        @POST("short")
        @Headers("Content-Type: application/json")
        Call<ResponseAnyang> getAnyang(@Body JsonObject jsonObject);
    }

    public interface IgetBeomgyedatas {//범계단거리
        @POST("short")
        @Headers("Content-Type: application/json")
        Call<MyResponseBeomgye>getBeomgye(@Body JsonObject jsonObject);
    }

    public interface IgetYeonsungdatas {//연성단거리
        @POST("short")
        @Headers("Content-Type: application/json")
        Call<ResponseYeonsung> getdatas(@Body JsonObject jsonObject);
    }

    public static class ResponseYeonsung {
        @SerializedName("ysbus1")
        private int ysbus1;
        @SerializedName("ysbus2")
        private int ysbus2;
        @SerializedName("ysbus3")
        private int ysbus3;
        @SerializedName("ysbus4")
        private int ysbus4;

        public int getYsbus1() {
            return ysbus1;
        }

        public void setYsbus1(int ysbus1) {
            this.ysbus1 = ysbus1;
        }

        public int getYsbus2() {
            return ysbus2;
        }

        public void setYsbus2(int ysbus2) {
            this.ysbus2 = ysbus2;
        }

        public int getYsbus3() {
            return ysbus3;
        }

        public void setYsbus3(int ysbus3) {
            this.ysbus3 = ysbus3;
        }

        public int getYsbus4() {
            return ysbus4;
        }

        public void setYsbus4(int ysbus4) {
            this.ysbus4 = ysbus4;
        }
    }

    public static class ResponseAnyang {
        @SerializedName("bus1")
        private int bus1;
        @SerializedName("bus2")
        private int bus2;
        @SerializedName("bus3")
        private int bus3;
        @SerializedName("bus4")
        private int bus4;


        public int getBus1() {
            return bus1;
        }

        public void setBus1(int bus1) {
            this.bus1 = bus1;
        }

        public int getBus2() {
            return bus2;
        }

        public void setBus2(int bus2) {
            this.bus2 = bus2;
        }

        public int getBus3() {
            return bus3;
        }

        public void setBus3(int bus3) {
            this.bus3 = bus3;
        }

        public int getBus4() {
            return bus4;
        }

        public void setBus4(int bus4) {
            this.bus4 = bus4;
        }


    }

    public static class MyResponseBeomgye {
        @SerializedName("Beomgye_1st")
        private int Beomgye_1st;
        @SerializedName("geo_state")
        private int geo_state;

        public int getBeomgye_1st() {
            return Beomgye_1st;
        }

        public void setBeomgye_1st(int beomgye_1st) {
            Beomgye_1st = beomgye_1st;
        }

        public int getGeo_state() {
            return geo_state;
        }

        public void setGeo_state(int geo_state) {
            this.geo_state = geo_state;
        }
    }

    public static class MyResponseIncheon {
        @SerializedName("Incheon_1st")
        private int Incheon_1st;
        @SerializedName("Incheon_2nd")
        private int Incheon_2nd;
        @SerializedName("Incheon_3rd")
        private int Incheon_3rd;
        @SerializedName("Incheon_4th")
        private int Incheon_4th;
        @SerializedName("Incheon_5th")
        private int Incheon_5th;
        @SerializedName("Incheon_6th")
        private int Incheon_6th;


        @SerializedName("geo_state")
        private int geo_state;

        public int getIncheon_1st() {
            return Incheon_1st;
        }

        public int getIncheon_2nd() {
            return Incheon_2nd;
        }

        public int getIncheon_3rd() {
            return Incheon_3rd;
        }

        public int getIncheon_4th() {
            return Incheon_4th;
        }

        public int getIncheon_5th() {
            return Incheon_5th;
        }

        public int getIncheon_6th() {
            return Incheon_6th;
        }


        public int getGeo_state() {
            return geo_state;
        }

        public void setIncheon_1st(int Incheon_1st) {
            this.Incheon_1st = Incheon_1st;
        }

        public void setIncheon_2nd(int Incheon_2nd) {
            this.Incheon_2nd = Incheon_2nd;
        }

        public void setIncheon_3rd(int Incheon_3rd) {
            this.Incheon_3rd = Incheon_3rd;
        }

        public void setIncheon_4th(int Incheon_4th) {
            this.Incheon_4th = Incheon_4th;
        }

        public void setIncheon_5th(int Incheon_5th) {
            this.Incheon_5th = Incheon_5th;
        }

        public void setIncheon_6th(int incheon_6th) {
            Incheon_6th = incheon_6th;
        }

        public void setGeo_state(int geo_state) {
            this.geo_state = geo_state;
        }
    }

    public static class MyResponseMokdong {
        @SerializedName("Mokdong_1st")
        private int Mokdong_1st;
        @SerializedName("Mokdong_2nd")
        private int Mokdong_2nd;
        @SerializedName("Mokdong_3rd")
        private int Mokdong_3rd;
        @SerializedName("Mokdong_4th")
        private int Mokdong_4th;
        @SerializedName("Mokdong_5th")
        private int Mokdong_5th;
        @SerializedName("Mokdong_6th")
        private int Mokdong_6th;
        @SerializedName("geo_state")
        private int geo_state;

        public int getMokdong_6th() {
            return Mokdong_6th;
        }

        public void setMokdong_6th(int mokdong_6th) {
            Mokdong_6th = mokdong_6th;
        }

        public int getMokdong_1st() {
            return Mokdong_1st;
        }

        public void setMokdong_1st(int mokdong_1st) {
            Mokdong_1st = mokdong_1st;
        }

        public int getMokdong_2nd() {
            return Mokdong_2nd;
        }

        public void setMokdong_2nd(int mokdong_2nd) {
            Mokdong_2nd = mokdong_2nd;
        }

        public int getMokdong_3rd() {
            return Mokdong_3rd;
        }

        public void setMokdong_3rd(int mokdong_3rd) {
            Mokdong_3rd = mokdong_3rd;
        }

        public int getMokdong_4th() {
            return Mokdong_4th;
        }

        public void setMokdong_4th(int mokdong_4th) {
            Mokdong_4th = mokdong_4th;
        }

        public int getMokdong_5th() {
            return Mokdong_5th;
        }

        public void setMokdong_5th(int mokdong_5th) {
            Mokdong_5th = mokdong_5th;
        }

        public int getGeo_state() {
            return geo_state;
        }

        public void setGeo_state(int geo_state) {
            this.geo_state = geo_state;
        }
    }

    // 서버로부터 받아온 응답을 저장하는 클래스
    public static class MyResponseSiheung {
        @SerializedName("Siheung_1st")
        private int Siheung_1st;
        @SerializedName("Siheung_2nd")
        private int Siheung_2nd;
        @SerializedName("Siheung_3rd")
        private int Siheung_3rd;
        @SerializedName("Siheung_4th")
        private int Siheung_4th;
        @SerializedName("Siheung_5th")
        private int Siheung_5th;
        @SerializedName("Siheung_6th")
        private int Siheung_6th;
        @SerializedName("Siheung_7th")
        private int Siheung_7th;
        @SerializedName("Siheung_8th")
        private int Siheung_8th;
        @SerializedName("Siheung_9th")
        private int Siheung_9th;
        @SerializedName("geo_state")
        private int geo_state;

        public int getSiheung_9th() {
            return Siheung_9th;
        }

        public void setSiheung_9th(int siheung_9th) {
            Siheung_9th = siheung_9th;
        }

        public int getSiheung_1st() {
            return Siheung_1st;
        }

        public void setSiheung_1st(int siheung_1st) {
            Siheung_1st = siheung_1st;
        }

        public int getSiheung_2nd() {
            return Siheung_2nd;
        }

        public void setSiheung_2nd(int siheung_2nd) {
            Siheung_2nd = siheung_2nd;
        }

        public int getSiheung_3rd() {
            return Siheung_3rd;
        }

        public void setSiheung_3rd(int siheung_3rd) {
            Siheung_3rd = siheung_3rd;
        }

        public int getSiheung_4th() {
            return Siheung_4th;
        }

        public void setSiheung_4th(int siheung_4th) {
            Siheung_4th = siheung_4th;
        }

        public int getSiheung_5th() {
            return Siheung_5th;
        }

        public void setSiheung_5th(int siheung_5th) {
            Siheung_5th = siheung_5th;
        }

        public int getSiheung_6th() {
            return Siheung_6th;
        }

        public void setSiheung_6th(int siheung_6th) {
            Siheung_6th = siheung_6th;
        }

        public int getSiheung_7th() {
            return Siheung_7th;
        }

        public void setSiheung_7th(int siheung_7th) {
            Siheung_7th = siheung_7th;
        }

        public int getSiheung_8th() {
            return Siheung_8th;
        }

        public void setSiheung_8th(int siheung_8th) {
            Siheung_8th = siheung_8th;
        }

        public int getGeo_state() {
            return geo_state;
        }

        public void setGeo_state(int geo_state) {
            this.geo_state = geo_state;
        }
    }

}
