package com.example.client_app;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {
    EditText edt_address;
    Button btn_address;
    SharedPreferences sharedPref;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt_address = findViewById(R.id.Edt_address);
        btn_address = findViewById(R.id.Btn_address);
        TabHost tabHost = getTabHost();

        TabSpec tabSpecLong = tabHost.newTabSpec("LONG").setIndicator("장거리 셔틀버스");
        tabSpecLong.setContent(R.id.tabLong);
        tabHost.addTab(tabSpecLong);

        TabSpec tabSpecShort = tabHost.newTabSpec("SHORT").setIndicator("단거리 셔틀버스");
        tabSpecShort.setContent(R.id.tabShort);
        tabHost.addTab(tabSpecShort);

        // 장거리 리스트뷰 시작
        ListView listViewLong = findViewById(R.id.listViewLong);

        ArrayAdapter<String> adapterLong = new ArrayAdapter<String>(this, R.layout.list_item, R.id.textViewBusRoute) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                ImageView imageViewBus = view.findViewById(R.id.imageViewBus);
                imageViewBus.setImageResource(R.drawable.ic_baseline_directions_bus_24);
                return view;
            }
        };

        adapterLong.add("\n서울시 목동구 -> 연성대\n서울남부지방법원 버스정류장 -> 연성대\n");
        adapterLong.add("\n인천시 남동구 -> 연성대\n모래내시장역 4번출구 버스정류장 -> 연성대\n");
        adapterLong.add("\n경기도 시흥시 -> 연성대\n시화공단 이마트 건너편 버스정류장 -> 연성대\n");

        listViewLong.setAdapter(adapterLong);

        listViewLong.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String selectedItem = adapterLong.getItem(position);
                if (selectedItem.equals("\n서울시 목동구 -> 연성대\n서울남부지방법원 버스정류장 -> 연성대\n")) {
                    Intent newintent = new Intent(MainActivity.this, MokdongActivity.class);
                    startActivity(newintent);
                } else if (selectedItem.equals("\n인천시 남동구 -> 연성대\n모래내시장역 4번출구 버스정류장 -> 연성대\n")) {
                    Intent newintent = new Intent(MainActivity.this, IncheonActivity.class);
                    startActivity(newintent);
                } else if (selectedItem.equals("\n경기도 시흥시 -> 연성대\n시화공단 이마트 건너편 버스정류장 -> 연성대\n")) {
                    Intent newintent = new Intent(MainActivity.this, SiheungActivity.class);
                    startActivity(newintent);
                }
            }
        });

        // 단거리 리스트뷰 시작
        ListView listViewShort = findViewById(R.id.listViewShort);

        ArrayAdapter<String> adapterShort = new ArrayAdapter<String>(this, R.layout.list_item, R.id.textViewBusRoute) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                ImageView imageViewBus = view.findViewById(R.id.imageViewBus);
                imageViewBus.setImageResource(R.drawable.ic_baseline_directions_bus_24);
                return view;
            }
        };

        adapterShort.add("\n연성대 -> 안양역\n정문 학생복지센터 앞 -> 안양역\n");
        adapterShort.add("\n안양역 -> 연성대\n1번출구 스쿨버스 승강장 -> 연성대\n");
        adapterShort.add("\n범계역 -> 연성대\n8번출구 건너편 시내버스 승강장 -> 연성대\n");

        listViewShort.setAdapter(adapterShort);

        listViewShort.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String selectedItem = adapterShort.getItem(position);
                if (selectedItem.equals("\n연성대 -> 안양역\n정문 학생복지센터 앞 -> 안양역\n")) {
                    Intent newintent = new Intent(MainActivity.this, YeonsungActivity.class);
                    startActivity(newintent);
                } else if (selectedItem.equals("\n안양역 -> 연성대\n1번출구 스쿨버스 승강장 -> 연성대\n")) {
                    Intent newintent = new Intent(MainActivity.this, AnyangActivity.class);
                    startActivity(newintent);
                } else if (selectedItem.equals("\n범계역 -> 연성대\n8번출구 건너편 시내버스 승강장 -> 연성대\n")) {
                    Intent newintent = new Intent(MainActivity.this, BeomgyeActivity.class);
                    startActivity(newintent);
                }
            }
        });

        tabHost.setCurrentTab(0);

        btn_address.setOnClickListener(new View.OnClickListener() {//주소확정
            @Override
            public void onClick(View view) {
                String address1 = edt_address.getText().toString();
                sharedPref = MainActivity.this.getSharedPreferences("address", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("add", address1);
                editor.apply();
            }
        });
    }
}
