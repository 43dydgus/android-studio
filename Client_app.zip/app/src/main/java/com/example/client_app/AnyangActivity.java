package com.example.client_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


//장거리-인천 남동구를 클릭했을때 실행되는 클래스파일!
public class AnyangActivity extends AppCompatActivity {
    Client client;
    int Anyang_1st; //안양역에 도착하는시간
    int Anyang_2nd;
    int Anyang_3rd;
    int Anyang_4th;
    List<Integer> busList = new ArrayList<>();//현재 운행중인 버스개수
    List<Integer> negativeOneIndices = new ArrayList<>(); //-1일떄 즉 도착한 버스
    int geo_state;
    ImageView renew;

    private ListView listView;
    private CustomAdapter adapter;
    private ArrayList<String> dataList;

    int hours;
    int minutes;
    int seconds;
    int t;//1분마다 실행할 변수

    String timeString1; //시간을 나타낼 문자열
    String timeString2;
    String timeString3;
    String timeString4;
    Handler handler;
    Thread thread;
    Runnable runnable;
    int timeCount = 60;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anyang);
        renew = findViewById(R.id.btn_renew);
        client = new Client();
        //--------------
        SharedPreferences sharedPref = getSharedPreferences("address", Context.MODE_PRIVATE);
        String ad_d = sharedPref.getString("add", "");
        client.setStr(ad_d);
        //--------------

        //커스텀 리스트뷰를 이용하는 코드입니다
        listView = findViewById(R.id.listView);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        listView.setAdapter(adapter);


        dataList.add("차량미운행중입니다");
        dataList.add("차량미운행중입니다");
        dataList.add("차량미운행중입니다");
        dataList.add("차량미운행중입니다");

        startThread();
        startHandler();

        renew.setOnClickListener(new View.OnClickListener() { //새로고침
            @Override
            public void onClick(View view) {
                startThread();
            }
        });
    }//onCreate

    public void startThread() {
        thread = new Thread(new Runnable() { //통신쓰레드 생성
            @Override
            public void run() {
                // 요청을 보내고, 서버로부터 응답을 받아옵니다.
                client.getAnyang("안양역", new Callback<Client.ResponseAnyang>() {
                    @Override
                    public void onResponse(Call<Client.ResponseAnyang> call, Response<Client.ResponseAnyang> response) {
                        //이 메소드에서 UI 변경이 더 복잡하고 오래 걸리는 작업을 하는 경우, UI 스레드를 차단하고 ANR발생가능성 콜백메소드이기떄문에 new thread이지만 UI변경가능하다
                        if (response.isSuccessful()) {
                            // 서버로부터 응답이 성공적으로 도착한 경우
                            // 받은 JSON 데이터 파싱
                            busList.clear();
                            negativeOneIndices.clear();
                            busList.add(response.body().getBus1());
                            busList.add(response.body().getBus2());
                            busList.add(response.body().getBus3());
                            busList.add(response.body().getBus4());

                            // 값이 0인 것을 제외하고 리스트를 오름차순으로 정렬
                            busList.removeIf(value -> value == 0);
                            Collections.sort(busList);
                            for (int i = 0; i < busList.size(); i++) {
                                int busValue = busList.get(i);
                                switch (i) {
                                    case 0:
                                        Anyang_1st = busValue;
                                        break;
                                    case 1:
                                        Anyang_2nd = busValue;
                                        break;
                                    case 2:
                                        Anyang_3rd = busValue;
                                        break;
                                    case 3:
                                        Anyang_4th = busValue;
                                        break;
                                    // 이 외에 필요한 경우 추가로 처리 가능
                                }
                            }
                            for (int i = 0; i < busList.size(); i++) {
                                int busValue = busList.get(i);
                                if (busValue == -1) {
                                    negativeOneIndices.add(i);
                                }
                            }
/*
                            Toast.makeText(AnyangActivity.this, "운행중인차량" + busList.size() + "도착차량" + negativeOneIndices.size(),
                                    Toast.LENGTH_SHORT).show();

 */

                        } else {
                            // 서버로부터 응답이 도착하지 않은 경우
                            /*
                            Toast.makeText(AnyangActivity.this, "서버무응답",
                                    Toast.LENGTH_SHORT).show();

                             */
                        }
                    }//onResponse

                    @Override
                    public void onFailure(Call<Client.ResponseAnyang> call, Throwable t) {
                        // onFailure() 메소드의 구현
                        Toast.makeText(AnyangActivity.this, t.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });//new Thread
        thread.start();
    }

    public void startHandler() {

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {

                // 1초 후에 다시 runnable 실행
                timeCount--;
                if (timeCount <= 0) {
                    startThread();
                    timeCount = 40; //40초에한번씩 새로고침
                }
                if (Anyang_1st > 0) {
                    Anyang_1st--;
                }
                if (Anyang_2nd > 0) {
                    Anyang_2nd--;
                }
                if (Anyang_3rd > 0) {
                    Anyang_3rd--;
                }
                if (Anyang_4th > 0) {
                    Anyang_4th--;
                }

                hours = Anyang_1st / 3600;
                minutes = (Anyang_1st % 3600) / 60;
                seconds = Anyang_1st % 60;
                timeString1 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Anyang_2nd / 3600;
                minutes = (Anyang_2nd % 3600) / 60;
                seconds = Anyang_2nd % 60;
                timeString2 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Anyang_3rd / 3600;
                minutes = (Anyang_3rd % 3600) / 60;
                seconds = Anyang_3rd % 60;
                timeString3 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Anyang_4th / 3600;
                minutes = (Anyang_4th % 3600) / 60;
                seconds = Anyang_4th % 60;
                timeString4 = hours + "시 " + minutes + "분 " + seconds + "초";


                if (busList.size() == 4) {
                    if (negativeOneIndices.size() == 4) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "3호차\n" + "안양역에 도착했습니다");
                        dataList.set(3, "4호차\n" + "안양역에 도착했습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 3) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "3호차\n" + "안양역에 도착했습니다");
                        dataList.set(3, "4호차\n" + "도착까지 남은시간:" + timeString4);
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 2) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "4호차\n" + "도착까지 남은시간:" + timeString4);
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 1) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "4호차\n" + "도착까지 남은시간:" + timeString4);
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 0) {
                        dataList.set(0, "1호차\n" + "도착까지 남은시간:" + timeString1);
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "4호차\n" + "도착까지 남은시간:" + timeString4);
                        adapter.notifyDataSetChanged();
                    }
                } else if (busList.size() == 3) {//운행중인 차량이3대
                    if (negativeOneIndices.size() == 3) { //도착한차량이3대
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "3호차\n" + "안양역에 도착했습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 2) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 1) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 0) {
                        dataList.set(0, "1호차\n" + "도착까지 남은시간:" + timeString1);
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "3호차\n" + "도착까지 남은시간:" + timeString3);
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    }
                } else if (busList.size() == 2) {//운행중인 차량이2대
                    if (negativeOneIndices.size() == 2) { //도착한차량이2대
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "안양역에 도착했습니다");
                        dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 1) {
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 0) {
                        dataList.set(0, "1호차\n" + "도착까지 남은시간:" + timeString1);
                        dataList.set(1, "2호차\n" + "도착까지 남은시간:" + timeString2);
                        dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    }
                } else if (busList.size() == 1) {//운행중인 차량이1대
                    if (negativeOneIndices.size() == 1) { //도착한차량이1대
                        dataList.set(0, "1호차\n" + "안양역에 도착했습니다");
                        dataList.set(1, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    } else if (negativeOneIndices.size() == 0) {
                        dataList.set(0, "1호차\n" + "도착까지 남은시간:" + timeString1);
                        dataList.set(1, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                        adapter.notifyDataSetChanged();
                    }
                } else if (busList.size() == 0) {//운행중인 차량이0대

                    dataList.set(0, "미운행중\n" + "운행중인 차량이없습니다");
                    dataList.set(1, "미운행중\n" + "운행중인 차량이없습니다");
                    dataList.set(2, "미운행중\n" + "운행중인 차량이없습니다");
                    dataList.set(3, "미운행중\n" + "운행중인 차량이없습니다");
                    adapter.notifyDataSetChanged();

                }
                handler.postDelayed(this, 1000);
            }
        }

        ;

        handler.post(runnable);

    }

    @Override
    public void onBackPressed() {
        // 뒤로가기 버튼 누를 때 Handler 중지
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }


        super.onBackPressed();

    }
}