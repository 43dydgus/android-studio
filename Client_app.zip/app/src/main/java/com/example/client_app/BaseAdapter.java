package com.example.client_app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//동적 데이터를 할당받을수 있는 커스텀 리스트뷰의 어탭더입니다
class CustomAdapter extends BaseAdapter {
    private ArrayList<String> dataList;

    public CustomAdapter(ArrayList<String> dataList) {
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
        }

        TextView textView = convertView.findViewById(android.R.id.text1);
        String text = dataList.get(position);
        textView.setText(text);
        textView.setBackgroundResource(android.R.drawable.edit_text);
        textView.setTextColor(Color.GRAY);

        return convertView;
    }
}
