package com.example.client_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


//장거리-인천 남동구를 클릭했을때 실행되는 클래스파일!
public class SiheungActivity extends AppCompatActivity {
    Client client;
    int Siheung_1st;
    int Siheung_2nd;
    int Siheung_3th;
    int Siheung_4th;
    int Siheung_5th;
    int Siheung_6th;
    int Siheung_7th;
    int Siheung_8th;
    int Siheung_9th;
    int geo_state;
    ImageView renew;

    private ListView listView;
    private CustomAdapter adapter;
    private ArrayList<String> dataList;

    int hours;
    int minutes;
    int seconds;
    int t;//1분마다 실행할 변수

    String timeString1;
    String timeString2;
    String timeString3;
    String timeString4;
    String timeString5;
    String timeString6;
    String timeString7;
    String timeString8;
    String timeString9;
    Handler handler;
    Thread thread;
    Runnable runnable;
    int timeCount = 60;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_siheung);
        renew = findViewById(R.id.btn_renew);
        client = new Client();
        //--------------
        SharedPreferences sharedPref = getSharedPreferences("address", Context.MODE_PRIVATE);
        String ad_d = sharedPref.getString("add", "");
        client.setStr(ad_d);
        //--------------

        //커스텀 리스트뷰를 이용하는 코드입니다
        listView = findViewById(R.id.listView);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        listView.setAdapter(adapter);


        dataList.add("시화공단 이마트 건너편 버스정류장\n" + "차량미운행중입니다");//시화공단 이마트 건너편 버스정류장
        dataList.add("정왕역 2번출구 한우직판장\n" + "차량미운행중입니다");//정왕역 2번출구 한우직판장
        dataList.add("장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "차량미운행중입니다");//장곡고교 앞 동양덱스빌 아파트 버스정류장
        dataList.add("장곡중학교 대우아파트 버스정류장\n" + "차량미운행중입니다");//장곡중학교 대우아파트 버스정류장
        dataList.add("시흥능곡역 SK시흥 주유소앞\n" + "차량미운행중입니다");//시흥능곡역 SK시흥 주유소앞
        dataList.add("시흥시청역 2번출구 건너편 버스정류장\n" + "차량미운행중입니다");//시흥시청역 2번출구 건너편 버스정류장
        dataList.add("시흥등기소입구 삼거리\n" + "차량미운행중입니다");//시흥등기소입구 삼거리
        dataList.add("안양역\n" + "차량미운행중입니다");//안양역
        dataList.add("연성대\n" + "차량미운행중입니다");//연성대    -9개-
        startThread();
        startHandler();

        renew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startThread();
            }
        });
    }//onCreate

    public void startThread() {
        thread = new Thread(new Runnable() { //통신쓰레드 생성
            @Override
            public void run() {
                // 요청을 보내고, 서버로부터 응답을 받아옵니다.
                client.getSiheung("시흥", new Callback<Client.MyResponseSiheung>() {
                    @Override
                    public void onResponse(Call<Client.MyResponseSiheung> call, Response<Client.MyResponseSiheung> response) {
                        //이 메소드에서 UI 변경이 더 복잡하고 오래 걸리는 작업을 하는 경우, UI 스레드를 차단하고 ANR발생가능성 콜백메소드이기떄문에 new thread이지만 UI변경가능하다
                        if (response.isSuccessful()) {
                            // 서버로부터 응답이 성공적으로 도착한 경우
                            Siheung_1st = response.body().getSiheung_1st();
                            Siheung_2nd = response.body().getSiheung_2nd();
                            Siheung_3th = response.body().getSiheung_3rd();
                            Siheung_4th = response.body().getSiheung_4th();
                            Siheung_5th = response.body().getSiheung_5th();
                            Siheung_6th = response.body().getSiheung_6th();
                            Siheung_7th = response.body().getSiheung_7th();
                            Siheung_8th = response.body().getSiheung_8th();
                            Siheung_9th = response.body().getSiheung_9th();

                            geo_state = response.body().getGeo_state();

                            Siheung_2nd += Siheung_1st;
                            Siheung_3th += Siheung_2nd;
                            Siheung_4th += Siheung_3th;
                            Siheung_5th += Siheung_4th;
                            Siheung_6th += Siheung_5th;
                            Siheung_7th += Siheung_6th;
                            Siheung_8th += Siheung_7th;
                            Siheung_9th += Siheung_8th;
                        } else {
                            // 서버로부터 응답이 도착하지 않은 경우
                              /*
                            Toast.makeText(MokdongActivity.this, "서버무응답",
                                    Toast.LENGTH_SHORT).show();

                             */

                        }
                    }//onResponse

                    @Override
                    public void onFailure(Call<Client.MyResponseSiheung> call, Throwable t) {
                        // onFailure() 메소드의 구현
                        Toast.makeText(SiheungActivity.this, t.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });//new Thread
        thread.start();
    }

    public void startHandler() {

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                timeCount--;
                if (timeCount <= 0) {
                    startThread();
                    timeCount = 60;
                }
                if (Siheung_1st > 0) {//만수역가는길
                    Siheung_1st--;
                }
                if (Siheung_2nd > 0) {//만수역 -> 남동구청
                    Siheung_2nd--;
                }
                if (Siheung_3th > 0) {//남동구청 -> 신천역
                    Siheung_3th--;
                }
                if (Siheung_4th > 0) { //신천역 -> 안양역
                    Siheung_4th--;
                }
                if (Siheung_5th > 0) { //안양역 -> 연성대
                    Siheung_5th--;
                }
                if (Siheung_6th > 0) {
                    Siheung_6th--;
                }
                if (Siheung_7th > 0) {
                    Siheung_7th--;
                }
                if (Siheung_8th > 0) {
                    Siheung_8th--;
                }
                if(Siheung_9th > 0){
                    Siheung_9th--;
                }
                // 1초 후에 다시 runnable 실행


                hours = Siheung_1st / 3600;
                minutes = (Siheung_1st % 3600) / 60;
                seconds = Siheung_1st % 60;
                timeString1 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_2nd / 3600;
                minutes = (Siheung_2nd % 3600) / 60;
                seconds = Siheung_2nd % 60;
                timeString2 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_3th / 3600;
                minutes = (Siheung_3th % 3600) / 60;
                seconds = Siheung_3th % 60;
                timeString3 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_4th / 3600;
                minutes = (Siheung_4th % 3600) / 60;
                seconds = Siheung_4th % 60;
                timeString4 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_5th / 3600;
                minutes = (Siheung_5th % 3600) / 60;
                seconds = Siheung_5th % 60;
                timeString5 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_6th / 3600;
                minutes = (Siheung_6th % 3600) / 60;
                seconds = Siheung_6th % 60;
                timeString6 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_7th / 3600;
                minutes = (Siheung_7th % 3600) / 60;
                seconds = Siheung_7th % 60;
                timeString7 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_8th / 3600;
                minutes = (Siheung_8th % 3600) / 60;
                seconds = Siheung_8th % 60;
                timeString8 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Siheung_9th / 3600;
                minutes = (Siheung_9th % 3600) / 60;
                seconds = Siheung_9th % 60;
                timeString9 = hours + "시 " + minutes + "분 " + seconds + "초";

                switch (geo_state) {
                    case -102://평소상태
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(7, "안양역\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(8, "연성대\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case -4://평소상태
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "도착까지 남은시간" + timeString1);
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(7, "안양역\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(8, "연성대\n" + "차량이 첫출발지로 가고있습니다");
                        adapter.notifyDataSetChanged();
                        break;

                    case -1://운행종료
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "차량미운행중입니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "차량미운행중입니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "차량미운행중입니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "차량미운행중입니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "차량미운행중입니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "차량미운행중입니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "차량미운행중입니다");
                        dataList.set(7, "안양역\n" + "차량미운행중입니다");
                        dataList.set(8, "연성대\n" + "차량미운행중입니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 41: //시화공단도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "시화공단역에 차량이 도착했습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(7, "안양역\n" + "시화공단역에서 출발준비중입니다");
                        dataList.set(8, "연성대\n" + "시화공단역에서 출발준비중입니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 42: //시화공단 -> 정왕역
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        if (Siheung_1st < 60) {
                            dataList.set(1, "정왕역 2번출구 한우직판장\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(1, "정왕역 2번출구 한우직판장\n" + "도착까지 남은시간" + timeString2);
                        }
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "도착까지 남은시간" + timeString3);
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 43: //정왕역 도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "해당역에 도착했습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "도착까지 남은시간" + timeString3);
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 44://정왕역 -> 장곡고교
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        if (Siheung_2nd < 60) {
                            dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "잠시후 도착합니다");
                        } else {
                            dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "도착까지 남은시간" + timeString3);
                        }
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 45://장곡고교 도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "해당역에 도착했습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 46://장곡고교 -> 장곡중학교
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        if (Siheung_3th < 60) {
                            dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "도착까지 남은시간" + timeString4);
                        }
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 47://장곡중학교 도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "해당역에 도착했습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 48://장곡중학교 -> 시흥능곡역
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        if (Siheung_4th < 60) {
                            dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "도착까지 남은시간" + timeString5);
                        } else {
                            dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "잠시후에 도착합니다");
                        }
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 49://시흥능곡역 도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "해당역에 도착했습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 50://시흥능곡역 -> 시흥시청역
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        if (Siheung_5th < 60) {
                            dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "도착까지 남은시간" + timeString6);
                        }
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 51://시흥시청역 도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "해당역에 도착했습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 52://시흥시청 -> 등기소
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        if (Siheung_6th < 60) {
                            dataList.set(6, "시흥등기소입구 삼거리\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(6, "시흥등기소입구 삼거리\n" + "도착까지 남은시간" + timeString7);
                        }
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 53://등기소도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "해당역에 도착했습니다");
                        dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 54://등기소 -> 안양역
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "운행중인 차량이없습니다");
                        if (Siheung_7th < 60) {
                            dataList.set(7, "안양역\n" + "잠시후 도착합니다");
                        } else {
                            dataList.set(7, "안양역\n" + "도착까지 남은시간" + timeString8);
                        }
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 55://안양역도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "운행중인 차량이없습니다");
                        dataList.set(7, "안양역\n" + "해당역에 도착했습니다");
                        dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        adapter.notifyDataSetChanged();
                        break;
                    case 56://안양역 -> 연성대
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "운행중인 차량이없습니다");
                        dataList.set(7, "안양역\n" + "운행중인 차량이없습니다");
                        if (Siheung_8th < 60) {
                            dataList.set(8, "연성대\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(8, "연성대\n" + "도착까지 남은시간" + timeString9);
                        }
                        adapter.notifyDataSetChanged();
                        break;
                    case 57://연성대도착
                        dataList.set(0, "시화공단 이마트 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "정왕역 2번출구 한우직판장\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "장곡고교 앞 동양덱스빌 아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "장곡중학교 대우아파트 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "시흥능곡역 SK시흥 주유소앞\n" + "운행중인 차량이없습니다");
                        dataList.set(5, "시흥시청역 2번출구 건너편 버스정류장\n" + "운행중인 차량이없습니다");
                        dataList.set(6, "시흥등기소입구 삼거리\n" + "운행중인 차량이없습니다");
                        dataList.set(7, "안양역\n" + "운행중인 차량이없습니다");
                        dataList.set(8, "연성대\n" + "해당역에 도착했습니다");
                        adapter.notifyDataSetChanged();
                        break;

                }
                handler.postDelayed(this, 1000);
            }
        }

        ;
        handler.post(runnable);
    }

    @Override
    public void onBackPressed() {
        // 뒤로가기 버튼 누를 때 Handler 중지
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }


        super.onBackPressed();

    }
}

