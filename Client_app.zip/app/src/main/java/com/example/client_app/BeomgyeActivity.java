package com.example.client_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


//장거리-인천 남동구를 클릭했을때 실행되는 클래스파일!
public class BeomgyeActivity extends AppCompatActivity {
    Client client;
    int Beomgye_1st;

    int geo_state;
    ImageView renew;

    private ListView listView;
    private CustomAdapter adapter;
    private ArrayList<String> dataList;

    int hours;
    int minutes;
    int seconds;

    String timeString1;
    Handler handler;
    Thread thread;
    Runnable runnable;
    int timeCount = 60;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beomgye);
        renew = findViewById(R.id.btn_renew);
        client = new Client();
        //--------------
        SharedPreferences sharedPref = getSharedPreferences("address", Context.MODE_PRIVATE);
        String ad_d = sharedPref.getString("add", "");
        client.setStr(ad_d);
        //--------------

        //커스텀 리스트뷰를 이용하는 코드입니다
        listView = findViewById(R.id.listView);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        listView.setAdapter(adapter);


        dataList.add("범계역\n" + "차량미운행중입니다");

        startThread();
        startHandler();


        renew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startThread();
            }
        });
    }//onCreate

    public void startThread() {
        thread = new Thread(new Runnable() { //통신쓰레드 생성
            @Override
            public void run() {
                // 요청을 보내고, 서버로부터 응답을 받아옵니다.
                client.getBeomgye("범계역", new Callback<Client.MyResponseBeomgye>() {
                    @Override
                    public void onResponse(Call<Client.MyResponseBeomgye> call, Response<Client.MyResponseBeomgye> response) {
                        //이 메소드에서 UI 변경이 더 복잡하고 오래 걸리는 작업을 하는 경우, UI 스레드를 차단하고 ANR발생가능성 콜백메소드이기떄문에 new thread이지만 UI변경가능하다
                        if (response.isSuccessful()) {
                            // 서버로부터 응답이 성공적으로 도착한 경우
                            Beomgye_1st = response.body().getBeomgye_1st();
                            geo_state = response.body().getGeo_state();

                        } else {
                            // 서버로부터 응답이 도착하지 않은 경우
                          /*
                            Toast.makeText(MokdongActivity.this, "서버무응답",
                                    Toast.LENGTH_SHORT).show();

                             */



                        }
                    }//onResponse

                    @Override
                    public void onFailure(Call<Client.MyResponseBeomgye> call, Throwable t) {
                        // onFailure() 메소드의 구현
                        Toast.makeText(BeomgyeActivity.this, t.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });//new Thread
        thread.start();
    }

    public void startHandler() {

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                timeCount--;
                if (timeCount <= 0) {
                    startThread();
                    timeCount = 60;
                }
                if(Beomgye_1st >0)
                {
                    Beomgye_1st --;
                }

                // 1초 후에 다시 runnable 실행


                hours = Beomgye_1st / 3600;
                minutes = (Beomgye_1st % 3600) / 60;
                seconds = Beomgye_1st % 60;
                timeString1 = hours + "시 " + minutes + "분 " + seconds + "초";


                switch (geo_state) {
                    case -104:
                        dataList.set(0, "범계역\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case -1:
                        dataList.set(0, "범계역\n" + "차량미운행중입니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 60://평소
                        dataList.set(0, "범계역\n" + "도착까지 남은시간:" + timeString1);
                        adapter.notifyDataSetChanged();
                        break;
                    case 61://범계역도착
                        dataList.set(0, "범계역\n" + "범계역에 도착했습니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 62://범계역 -> 연성대
                        dataList.set(0, "범계역\n" + "차량이 연성대로 이동중입니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 63://연성대
                        dataList.set(0, "범계역\n" + "연성대에 도착했습니다");
                        adapter.notifyDataSetChanged();
                        break;


                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(runnable);
    }

    @Override
    public void onBackPressed() {
        // 뒤로가기 버튼 누를 때 Handler 중지
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }


        super.onBackPressed();

    }
}