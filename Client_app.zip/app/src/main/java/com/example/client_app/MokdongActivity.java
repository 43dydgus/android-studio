package com.example.client_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


//장거리-인천 남동구를 클릭했을때 실행되는 클래스파일!
public class MokdongActivity extends AppCompatActivity {
    Client client;
    int Mokdong_1st;
    int Mokdong_2nd;
    int Mokdong_3rd;
    int Mokdong_4th;
    int Mokdong_5th;
    int Mokdong_6th;
    int geo_state;
    ImageView renew;

    private ListView listView;
    private CustomAdapter adapter;
    private ArrayList<String> dataList;

    int hours;
    int minutes;
    int seconds;

    String timeString1;
    String timeString2;
    String timeString3;
    String timeString4;
    String timeString5;
    String timeString6;
    Handler handler;
    Thread thread;
    Runnable runnable;
    int timeCount = 60;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mokdong);
        renew = findViewById(R.id.btn_renew);
        client = new Client();
        //--------------
        SharedPreferences sharedPref = getSharedPreferences("address", Context.MODE_PRIVATE);
        String ad_d = sharedPref.getString("add", "");
        client.setStr(ad_d);
        //--------------

        //커스텀 리스트뷰를 이용하는 코드입니다
        listView = findViewById(R.id.listView);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        listView.setAdapter(adapter);


        dataList.add("서울남부지방법원버스정류장(진명여고방향)\n" + "차량미운행중입니다");//모래내시장
        dataList.add("진명여고\n" + "차량미운행중입니다");//만수역
        dataList.add("목동역5번출구\n" + "차량미운행중입니다");//남동구청역
        dataList.add("오목교역4번출구\n" + "차량미운행중입니다");//시흥 신천역
        dataList.add("안양역\n" + "차량미운행중입니다");//안양역
        dataList.add("연성대\n" + "차량미운행중입니다");//연성대

        startThread();
        startHandler();


        renew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startThread();
            }
        });
    }//onCreate

    public void startThread() {
        thread = new Thread(new Runnable() { //통신쓰레드 생성
            @Override
            public void run() {
                // 요청을 보내고, 서버로부터 응답을 받아옵니다.
                client.getMokdong("목동", new Callback<Client.MyResponseMokdong>() {
                    @Override
                    public void onResponse(Call<Client.MyResponseMokdong> call, Response<Client.MyResponseMokdong> response) {
                        //이 메소드에서 UI 변경이 더 복잡하고 오래 걸리는 작업을 하는 경우, UI 스레드를 차단하고 ANR발생가능성 콜백메소드이기떄문에 new thread이지만 UI변경가능하다
                        if (response.isSuccessful()) {
                            // 서버로부터 응답이 성공적으로 도착한 경우
                            Mokdong_1st = response.body().getMokdong_1st();
                            Mokdong_2nd = response.body().getMokdong_2nd();
                            Mokdong_3rd = response.body().getMokdong_3rd();
                            Mokdong_4th = response.body().getMokdong_4th();
                            Mokdong_5th = response.body().getMokdong_5th();
                            Mokdong_6th = response.body().getMokdong_6th();
                            geo_state = response.body().getGeo_state();

                            Mokdong_2nd += Mokdong_1st;
                            Mokdong_3rd += Mokdong_2nd;
                            Mokdong_4th += Mokdong_3rd;
                            Mokdong_5th += Mokdong_4th;
                            Mokdong_6th += Mokdong_5th;


                        } else {
                            // 서버로부터 응답이 도착하지 않은 경우
                            /*
                            Toast.makeText(MokdongActivity.this, "서버무응답",
                                    Toast.LENGTH_SHORT).show();

                             */

                        }
                    }//onResponse

                    @Override
                    public void onFailure(Call<Client.MyResponseMokdong> call, Throwable t) {
                        // onFailure() 메소드의 구현
                        Toast.makeText(MokdongActivity.this, t.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });//new Thread
        thread.start();
    }

    public void startHandler() {

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                timeCount--;
                if (timeCount <= 0) {
                    startThread();
                    timeCount = 60;
                }
                if (Mokdong_1st > 0) {//만수역가는길
                    Mokdong_1st--;
                }
                if (Mokdong_2nd > 0) {//만수역 -> 남동구청
                    Mokdong_2nd--;
                }
                if (Mokdong_3rd > 0) {//남동구청 -> 신천역
                    Mokdong_3rd--;
                }
                if (Mokdong_4th > 0) { //신천역 -> 안양역
                    Mokdong_4th--;
                }
                if (Mokdong_5th > 0) { //안양역 -> 연성대
                    Mokdong_5th--;
                }
                if(Mokdong_6th > 0){
                    Mokdong_6th--;
                }

                // 1초 후에 다시 runnable 실행


                hours = Mokdong_1st / 3600;
                minutes = (Mokdong_1st % 3600) / 60;
                seconds = Mokdong_1st % 60;
                timeString1 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Mokdong_2nd / 3600;
                minutes = (Mokdong_2nd % 3600) / 60;
                seconds = Mokdong_2nd % 60;
                timeString2 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Mokdong_3rd / 3600;
                minutes = (Mokdong_3rd % 3600) / 60;
                seconds = Mokdong_3rd % 60;
                timeString3 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Mokdong_4th / 3600;
                minutes = (Mokdong_4th % 3600) / 60;
                seconds = Mokdong_4th % 60;
                timeString4 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Mokdong_5th / 3600;
                minutes = (Mokdong_5th % 3600) / 60;
                seconds = Mokdong_5th % 60;
                timeString5 = hours + "시 " + minutes + "분 " + seconds + "초";

                hours = Mokdong_6th / 3600;
                minutes = (Mokdong_6th % 3600) / 60;
                seconds = Mokdong_6th % 60;
                timeString6 = hours + "시 " + minutes + "분 " + seconds + "초";

                switch (geo_state) {
                    case -101: //평소상태
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(1, "진명여고\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(2, "목동역5번출구\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(3, "오목교역4번출구\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(4, "안양역\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        dataList.set(5, "연성대\n" + "현재 차량에 문제가 생겨 운행이 불가능합니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case -3: //평소상태
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "도착까지 남은시간" + timeString1);
                        dataList.set(1, "진명여고\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(2, "목동역5번출구\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(3, "오목교역4번출구\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(4, "안양역\n" + "차량이 첫출발지로 가고있습니다");
                        dataList.set(5, "연성대\n" + "차량이 첫출발지로 가고있습니다");
                        adapter.notifyDataSetChanged();
                        break;

                    case -1: //운행종료
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "차량미운행중입니다");
                        dataList.set(1, "진명여고\n" + "차량미운행중입니다");
                        dataList.set(2, "목동역5번출구\n" + "차량미운행중입니다");
                        dataList.set(3, "오목교역4번출구\n" + "차량미운행중입니다");
                        dataList.set(4, "안양역\n" + "차량미운행중입니다");
                        dataList.set(5, "연성대\n" + "차량미운행중입니다");
                        adapter.notifyDataSetChanged();
                        break;
                    case 21: //남부지방법원도착
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "해당역에 도착했습니다");
                        dataList.set(1, "진명여고\n" + "도착까지 남은시간" + timeString2);
                        dataList.set(2, "목동역5번출구\n" + "도착까지 남은시간" + timeString3);
                        dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 22: //남부지방법원 -> 진명여고
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        if (Mokdong_1st < 60) {
                            dataList.set(1, "진명여고\n" + "잠시후 도착합니다");
                        } else {
                            dataList.set(1, "진명여고\n" + "도착까지 남은시간" + timeString2);
                        }
                        dataList.set(2, "목동역5번출구\n" + "도착까지 남은시간" + timeString3);
                        dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 23: //진명여고 도착
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "해당역에 도착했습니다");
                        dataList.set(2, "목동역5번출구\n" + "도착까지 남은시간" + timeString3);
                        dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 24: //진명여고 -> 목동역 5번출구
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        if (Mokdong_2nd < 60) {
                            dataList.set(2, "목동역5번출구\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(2, "목동역5번출구\n" + "도착까지 남은시간" + timeString3);
                        }
                        dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 25: //목동역 5번출구 도착
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "해당역에 도착했습니다");
                        dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 26: //목동역 -> 오목교역
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        if (Mokdong_3rd < 60) {
                            dataList.set(3, "오목교역4번출구\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(3, "오목교역4번출구\n" + "도착까지 남은시간" + timeString4);
                        }
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 27: //오목교역 도착
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "오목교역4번출구\n" + "해당역에 도착했습니다");
                        dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 28: //오목교역 ->안양역
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "오목교역4번출구\n" + "운행중인 차량이없습니다");
                        if (Mokdong_4th < 60) {
                            dataList.set(4, "안양역\n" + "잠시후 도착합니다");
                        } else {
                            dataList.set(4, "안양역\n" + "도착까지 남은시간" + timeString5);
                        }
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 29: //안양역
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "오목교역4번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "안양역\n" + "해당역에 도착했습니다");
                        dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        adapter.notifyDataSetChanged();
                        break;
                    case 30: //안양역->연성대
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "오목교역4번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "안양역\n" + "운행중인 차랑이없습니다");
                        if (Mokdong_5th < 60) {
                            dataList.set(5, "연성대\n" + "잠시후에 도착합니다");
                        } else {
                            dataList.set(5, "연성대\n" + "도착까지 남은시간" + timeString6);
                        }
                        adapter.notifyDataSetChanged();
                        break;
                    case 31: //연성대도착
                        dataList.set(0, "서울남부지방법원버스정류장(진명여고방향)\n" + "운행중인 차량이없습니다");
                        dataList.set(1, "진명여고\n" + "운행중인 차량이없습니다");
                        dataList.set(2, "목동역5번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(3, "오목교역4번출구\n" + "운행중인 차량이없습니다");
                        dataList.set(4, "안양역\n" + "운행중인 차랑이없습니다");
                        dataList.set(5, "연성대\n" + "해당역에 도착했습니다");
                        adapter.notifyDataSetChanged();
                        break;
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(runnable);
    }

    @Override
    public void onBackPressed() {
        // 뒤로가기 버튼 누를 때 Handler 중지
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }


        super.onBackPressed();

    }
}